﻿using System;
using System.Xml.Schema;

namespace Problem
{
    class Program
    {
        static void Main(string[] args)
        {
            int total1 = 0;
            int total2 = 0;
            int total3 = 0;
            int total4 = 0;
            int total5 = 0; 
            int myVar = 7;


            total1 = -1 + 4 * myVar;
            total2 = (35 + 5) % myVar;
            total3 = 14 + -4 * 6 / 12;
            total4 = 2 + 12 / 6 * 1 -myVar % 2;

            total5 = myVar * myVar;


            Console.WriteLine(total1);
            Console.WriteLine(total2);
            Console.WriteLine(total3);
            Console.WriteLine(total4);



            if (total5 > 4)
            {  Console.WriteLine("myVar is greater than 4");
            }
            else
            { Console.WriteLine("myVar is less than 4"); 
            }

          











        }
    }
}