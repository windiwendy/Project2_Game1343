﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Diagnostics;
using static System.Net.Mime.MediaTypeNames;

namespace Week7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int wC = 0;
            

            Console.WriteLine("Please enter a valid path: ");
            
            string line = Console.ReadLine();

            var location = new Regex(@"^\w{1}:((/*)((\s*)[A-Za-z0-9]))+\.+\w{3}$");

            
            try
            {
                if (location.IsMatch(line))
                {
                    Console.WriteLine("File path is valid");

                    readfile(line, wC);




                }
                else
                {
                    Console.WriteLine("Not a valid file path!");
                }

            }
            catch
            {
                Console.WriteLine("Unfortunately, that file does not exist");
            }









        }

        static void readfile(string lines, int wC)
        {

            int myWord = 1;
            string hold;
            int a = 0;




           StreamReader reader = new StreamReader(lines);
           //Console.WriteLine(reader.ReadLine());
           hold = reader.ReadLine();
            Console.WriteLine(hold);

            while (a <= hold.Length -1)
            {
                if (hold[a]==' ' || hold[a] == '\t')
                {
                    myWord++;
                }
                a++;
            }
            Console.WriteLine("words : {0} ", myWord);

        }



       
    }
}